package com.readme.rss.data.entity.compositeKey;

import java.io.Serializable;

public class ProjectPK implements Serializable {
    String id;
    String file_name;
    String file_path;

//    public ProjectPK(String id, String file_name, String file_path) {
//        this.id = id;
//        this.file_name = file_name;
//        this.file_path = file_path;
//    }
}
